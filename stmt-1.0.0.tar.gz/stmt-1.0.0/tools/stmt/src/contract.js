import { readFileSync } from 'node:fs';
export const contract = JSON.parse(readFileSync(new URL('../sql/contract.json', import.meta.url), 'utf8'));
export const writesPolicy = new Set(['init', 'scope-add', 'create', 'revise', 'import']);
