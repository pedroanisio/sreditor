import { randomUUID } from 'node:crypto';
import { conflict, id, integer, keys, missing, need, now, stable, string, transaction } from './common.js';

function rows(store, eventId) {
  if (!store.db.prepare('SELECT 1 FROM events WHERE scope=? AND id=?').get(store.scope, eventId)) missing();
  return store.db.prepare(`SELECT * FROM work_items WHERE scope=? AND event_id=? ORDER BY rank`).all(store.scope,
    eventId);
}

function publicItem(item) {
  const { scope, event_id, statement_id, revision, operation, action_id, state, worker, lease_until } = item;
  return {
    scope,
    event_id,
    statement_id,
    revision,
    operation,
    action_id,
    state,
    worker,
    lease_until,
    requires: JSON.parse(item.requires),
    result: JSON.parse(item.result)
  };
}
export function work(store, eventId) {
  return rows(store, id(eventId, 'event ID')).map(publicItem);
}
export function claim(store, data, clock) {
  keys(data, ['event_id', 'worker', 'lease_seconds']);
  const eventId = id(data.event_id, 'event ID'),
    worker = id(data.worker, 'worker');
  const { lease_seconds: seconds = 60 } = data;
  integer(seconds, 'lease_seconds', 1, 3600);
  return transaction(store.db, () => {
    const time = clock ?? now(),
      items = rows(store, eventId);
    const item = items.find(r => r.state === 'ready' || (r.state === 'leased' && r.lease_until <= time));
    if (!item) return { item: null };
    const token = randomUUID(),
      until = time + seconds;
    store.db.prepare("UPDATE work_items SET state='leased',worker=?,token=?,lease_until=? WHERE action_id=?")
      .run(worker, token, until, item.action_id);
    const parents = new Set(JSON.parse(item.requires));
    const inputs = Object.fromEntries(items.filter(r => parents.has(r.statement_id))
      .map(r => [r.statement_id, { action_id: r.action_id, revision: r.revision, result: JSON.parse(r.result) }]));
    return { item: { ...publicItem(item), state: 'leased', worker, lease_until: until, token, inputs } };
  });
}

function releaseDependents(store, eventId) {
  const items = rows(store, eventId),
    states = new Map(items.map(r => [r.statement_id, r.state]));
  const update = store.db.prepare('UPDATE work_items SET state=? WHERE action_id=?');
  // rank is topological, so cancellation propagates through all descendants in one scan.
  for (const item of items.filter(r => r.state === 'waiting')) {
    const deps = JSON.parse(item.requires).map(key => states.get(key));
    const state = deps.some(v => v === 'failed' || v === 'cancelled') ? 'cancelled' :
      deps.every(v => v === 'succeeded') ? 'ready' : 'waiting';
    if (state !== item.state) {
      update.run(state, item.action_id);
      states.set(item.statement_id, state);
    }
  }
}
export function acknowledge(store, data, clock) {
  keys(data, ['action_id', 'token', 'status', 'result']);
  const action = id(data.action_id, 'action ID'),
    token = string(data.token, 'lease token', 128);
  need(['succeeded', 'failed'].includes(data.status), 'status must be succeeded or failed');
  const result = stable(data.result ?? null);
  return transaction(store.db, () => {
    const item = store.db.prepare('SELECT * FROM work_items WHERE scope=? AND action_id=?').get(store.scope,
    action);
    if (!item) missing();
    if (item.token !== token) conflict('Stale or incorrect lease token');
    if (item.state === data.status && item.result === result) return { action_id: action, state: item.state,
      replayed: true };
    if (item.state !== 'leased' || item.lease_until <= (clock ?? now())) conflict(
      'Lease expired or already finalized');
    store.db.prepare('UPDATE work_items SET state=?,result=?,lease_until=NULL WHERE action_id=?').run(data.status,
      result, action);
    releaseDependents(store, item.event_id);
    return { action_id: action, state: data.status, replayed: false };
  });
}
