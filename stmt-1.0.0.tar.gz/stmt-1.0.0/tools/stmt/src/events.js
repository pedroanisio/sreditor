import { active } from './store.js';
import { bindings, matches } from './cel.js';
import { conflict, digest, id, integer, keys, missing, need, now, object, operation, stable,
  transaction } from './common.js';
import { slots } from './schedule.js';

function evaluate(rows, ctx, event, store) {
  const vars = bindings(ctx, event, store.scope, store.domain),
    matched = [],
    errors = [],
    unmatched = [];
  for (const r of rows) {
    const verdict = matches(r.conditionals, vars);
    if (verdict.error) errors.push({ id: r.id, revision: r.revision, ...verdict.error });
    else if (verdict.match) matched.push(r);
    else unmatched.push({ id: r.id, revision: r.revision, reason: 'condition_false' });
  }
  return { matched, errors, unmatched };
}
export function resolve(store, data) {
  keys(data, ['context', 'event']);
  const { context = {}, event = {} } = data;
  const { matched, errors, unmatched } = evaluate(active(store), context, object(event), store);
  const winners = new Map(),
    effective = [],
    shadowed = [];
  for (const r of matched) {
    const winner = winners.get(r.override_key);
    if (winner) shadowed.push({ ...reference(r), override_key: r.override_key, shadowed_by: winner });
    else {
      effective.push(r);
      if (r.override_key !== null) winners.set(r.override_key, r.id);
    }
  }
  return { matched: effective, shadowed, unmatched, errors };
}

function reference(r) {
  return { id: r.id, revision: r.revision, scope: r.scope, priority: r.priority, statement: r.statement };
}

function orderChain(rows) {
  const pending = [...rows],
    admitted = new Set(),
    ordered = [];
  while (pending.length) {
    const next = pending.findIndex(r => r.requires.every(k => admitted.has(k)));
    if (next < 0) break;
    const [r] = pending.splice(next, 1);
    ordered.push(r);
    admitted.add(r.id);
  }
  return { ordered, skipped: pending.map(r => ({ ...reference(r), unmet: r.requires.filter(k => !admitted.has(k)) })) };
}

function load(store, key) {
  return store.db.prepare('SELECT * FROM events WHERE scope=? AND id=?').get(store.scope, key);
}
export function inspect(store, key) {
  const row = load(store, id(key, 'event ID'));
  if (!row) missing();
  return { input: JSON.parse(row.input), ...JSON.parse(row.decision), created_at: row.created_at, sequence: row
    .sequence };
}
export function journal(store, data) {
  keys(data, ['after', 'limit', 'pending_only']);
  const { after = 0, limit = 50, pending_only: pending = false } = data;
  integer(after, 'after');
  integer(limit, 'limit', 1, 200);
  need(typeof pending === 'boolean', 'pending_only must be Boolean');
  const rows = store.db.prepare(`SELECT e.sequence,e.id,e.root,e.created_at,
    e.input ->> '$.phase' AS phase,e.decision ->> '$.decision' AS decision,
    (SELECT count(*) FROM work_items w WHERE w.scope=e.scope AND w.event_id=e.id
      AND w.state IN ('waiting','ready','leased')) AS unfinished
    FROM events e WHERE e.scope=? AND e.sequence>? AND (?=0 OR unfinished>0)
    ORDER BY e.sequence LIMIT ?`).all(store.scope, after, Number(pending), limit + 1);
  const page = rows.slice(0, limit);
  return { events: page, cursor: page.at(-1)?.sequence ?? after, has_more: rows.length > limit };
}

function lineage(store, input) {
  let ancestor = input.cause,
    depth = 0,
    root = input.id;
  while (ancestor) {
    const row = load(store, ancestor);
    if (!row) missing();
    const parent = JSON.parse(row.input),
      decision = JSON.parse(row.decision).decision;
    need(decision === 'ALLOW' || decision === 'ACCEPT', 'Parent event did not permit work');
    need(++depth <= 16, 'Causal depth exceeds 16');
    need(parent.phase !== input.phase || parent.operation !== input.operation, 'Causal operation cycle');
    root = ancestor;
    ancestor = parent.cause;
  }
  return { root, depth };
}

function record(store, input, candidates) {
  const { db, scope, domain } = store, prior = load(store, input.id);
  if (prior) {
    if (prior.input !== stable(input)) conflict('Event ID already binds a different payload');
    return { ...JSON.parse(prior.decision), replayed: true };
  }
  const { root, depth } = lineage(store, input);
  const event = {
    id: input.id,
    phase: input.phase,
    operation: input.operation,
    slot: input.slot,
    cause: input.cause,
    root,
    result: input.result ?? null
  };
  const { matched, errors, unmatched } = evaluate(candidates, input.context, event, store);
  const blocks = matched.filter(r => r.rule.effect === 'BLOCK');
  const chain = orderChain(matched.filter(r => r.rule.effect === 'ACT'));
  const decision = blocks.length ? 'BLOCK' : errors.length ? 'INDETERMINATE' : input.phase === 'BEFORE' ? 'ALLOW' :
    'ACCEPT';
  const run = decision === 'ALLOW' || decision === 'ACCEPT';
  const actions = run ? chain.ordered.map(r => ({
    ...reference(r),
    operation: r.rule.action.operation,
    requires: r.requires,
    action_id: digest([domain, scope, input.id, r.id])
  })) : [];
  const result = {
    event_id: input.id,
    domain,
    scope,
    root,
    depth,
    decision,
    blocks: blocks.map(reference),
    errors,
    skipped: chain.skipped,
    actions,
    matched: matched.map(reference),
    unmatched
  };
  db.prepare(`INSERT INTO events(scope,id,input,decision,root,depth,slot,created_at,sequence)
    SELECT ?,?,?,?,?,?,?,?,coalesce(max(sequence),0)+1 FROM events WHERE scope=?`)
    .run(scope, input.id, stable(input), stable(result), root, depth, input.slot, now(), scope);
  const receipt = 'engine:' + digest([domain, scope, input.id]);
  const saveReceipt = db.prepare('INSERT INTO rule_occurrences(statement_id,revision,occurrence_id) VALUES(?,?,?)');
  for (const r of [...blocks, ...actions]) saveReceipt.run(r.id, r.revision, receipt);
  const put = db.prepare(`INSERT INTO work_items(scope,event_id,statement_id,revision,action_id,operation,rank,requires,state)
    VALUES(?,?,?,?,?,?,?,?,?)`);
  actions.forEach((a, i) => put.run(scope, input.id, a.id, a.revision, a.action_id, a.operation, i, stable(a.requires),
    a.requires.length ? 'waiting' : 'ready'));
  return { ...result, replayed: false };
}
export function deliver(store, phase, data) {
  keys(data, phase === 'AFTER' ? ['id', 'operation', 'context', 'cause', 'result'] : ['id', 'operation', 'context',
    'cause'
  ], 'event');
  const key = id(data.id, 'event ID');
  need(!key.startsWith('schedule:'), 'Reserved scheduler event ID');
  const { context = {}, cause = null } = data;
  const op = operation(data.operation),
    ctx = object(context);
  if (cause !== null) id(cause, 'cause');
  const input = { id: key, operation: op, phase, context: ctx, cause, slot: null, result: data.result ?? null };
  return transaction(store.db, () => {
    const candidates = active(store).filter(r => r.rule?.trigger.kind === 'EVENT' &&
      r.rule.trigger.phase === phase && r.rule.trigger.operation === op);
    return record(store, input, candidates);
  });
}
export function tick(store, data) {
  keys(data, ['from', 'until', 'context']);
  const from = integer(data.from, 'from'),
    until = integer(data.until, 'until', from + 1, now());
  need(until - from <= 86400, 'Window exceeds 24 hours');
  const { context = {} } = data;
  const ctx = object(context);
  return transaction(store.db, () => {
    const bySlot = new Map();
    for (const row of active(store)) {
      const t = row.rule?.trigger;
      if (t?.kind !== 'SCHEDULE') continue;
      const end = row.expires_at === null ? until : Math.min(until, row.expires_at - 1);
      for (const slot of slots(t, from, end, row.revised_at)) {
        if (!bySlot.has(slot)) bySlot.set(slot, []);
        bySlot.get(slot).push(row);
      }
    }
    const old = store.db.prepare('SELECT slot FROM events WHERE scope=? AND slot>? AND slot<=?').all(store.scope,
      from, until);
    for (const { slot } of old)
      if (!bySlot.has(slot)) bySlot.set(slot, []);
    need(bySlot.size <= 1000, 'More than 1000 slots; use a smaller window');
    return {
      events: [...bySlot.keys()].sort((a, b) => a - b).map(slot => record(store, {
        id: 'schedule:' + slot,
        operation: null,
        phase: 'SCHEDULE',
        cause: null,
        slot,
        context: ctx
      }, bySlot.get(slot)))
    };
  });
}
