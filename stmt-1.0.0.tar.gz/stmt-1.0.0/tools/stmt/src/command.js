import { parseArgs } from 'node:util';
import { openSync, readSync, closeSync } from 'node:fs';
import { resolve as absolute, basename } from 'node:path';
import { Fault, integer, keys, missing, need, object, transaction, visible, scopePath } from './common.js';
import { contract, writesPolicy } from './contract.js';
import { openStore, active, exportScope, get, save } from './store.js';
import { resolve, deliver, inspect, journal, tick } from './events.js';
import { work, claim, acknowledge } from './work.js';
import { convertMarkdown } from './markdown.js';

const bools = ['help', 'version', 'adopt'];
const flags = Object.fromEntries(['db', 'domain', 'scope', 'file', 'json', 'context', 'category', 'if-revision',
    'revision', 'markdown', ...bools
  ]
  .map(k => [k, { type: bools.includes(k) ? 'boolean' : 'string' }]));

function options(argv) {
  try { return parseArgs({ args: argv, options: flags, allowPositionals: true }); } catch (e) { throw new Fault('USAGE',
      e.message); }
}

function readText(path, preserveBOM = false) {
  const fd = path === '-' ? 0 : openSync(path, 'r');
  try {
    const buf = Buffer.alloc(1048577);
    let size = 0;
    while (size < buf.length) {
      const n = readSync(fd, buf, size, buf.length - size, null);
      if (!n) break;
      size += n;
    }
    need(size <= 1048576, 'Input exceeds 1 MiB');
    return new TextDecoder('utf-8', { fatal: true, ignoreBOM: preserveBOM }).decode(buf.subarray(0, size));
  } finally { if (fd !== 0) closeSync(fd); }
}

function json(text) {
  need(Buffer.byteLength(text) <= 1048576, 'Input exceeds 1 MiB');
  try {
    return JSON.parse(text, (_key, value) => {
      if (typeof value === 'number') need(Number.isFinite(value) && (!Number.isInteger(value) || Number
        .isSafeInteger(value)), 'Unsafe JSON number');
      return value;
    });
  } catch (err) { if (err instanceof Fault) throw err; throw new Fault('INVALID_JSON', 'Expected valid JSON'); }
}

function input(opts) {
  need(!(opts.file !== undefined && opts.json !== undefined), 'Choose one JSON input source');
  return object(opts.file !== undefined ? json(readText(opts.file)) : opts.json !== undefined ? json(opts.json) : {});
}

function numeric(text, name, minimum) {
  need(typeof text === 'string' && /^\d+$/.test(text), name + ' requires an integer');
  return integer(Number(text), name, minimum);
}

function boundary(o, env, cmd) {
  const path = o.db ?? env.STMT_DB,
    domain = o.domain ?? env.STMT_DOMAIN,
    scope = o.scope ?? env.STMT_SCOPE;
  if (env.STMT_DB && o.db && absolute(o.db) !== absolute(env.STMT_DB)) missing();
  if (env.STMT_DOMAIN && domain !== env.STMT_DOMAIN) missing();
  if (env.STMT_SCOPE && !visible(scopePath(env.STMT_SCOPE), scopePath(scope))) missing();
  const mode = env.STMT_POLICY_MODE ?? 'author';
  need(['author', 'consume'].includes(mode), 'Invalid policy mode');
  if (mode === 'consume' && writesPolicy.has(cmd)) throw new Fault('READ_ONLY_POLICY', 'Policy authoring is disabled',
    6);
  return openStore(path, domain, scope, cmd === 'init', !!o.adopt, cmd === 'scope-add');
}

function route(s, cmd, key, o, data) {
  switch (cmd) {
    case 'init':
    case 'scope-add':
      return { domain: s.domain, scope: s.scope, engine_schema: 1, statement_schema: 2 };
    case 'create':
    case 'revise':
      return save(s, [{ id: key, expected_revision: cmd === 'create' ? 0 : numeric(o['if-revision'], '--if-revision',
          1), document: data }])[0];
    case 'import': {
      const bundle = data.ok === true ? data.result : data;
      keys(bundle, ['statements', 'source', 'sha256'], 'bundle');
      return { statements: save(s, bundle.statements, true) };
    }
    case 'export':
      return exportScope(s);
    case 'get':
      return get(s, key, o.revision === undefined ? undefined : numeric(o.revision, '--revision', 1));
    case 'history':
      return get(s, key, undefined, true);
    case 'list':
      return active(s).filter(r => o.category === undefined || r.category === o.category);
    case 'resolve':
    case 'match': {
      if (o.context !== undefined) {
        need(!('context' in data), 'Supply context once');
        data = { ...data, context: json(o.context) };
      }
      return resolve(s, data);
    }
    case 'gate':
      return deliver(s, 'BEFORE', data);
    case 'emit':
      return deliver(s, 'AFTER', data);
    case 'event':
      return inspect(s, key);
    case 'events':
      return journal(s, data);
    case 'tick':
      return tick(s, data);
    case 'work':
      return work(s, key);
    case 'claim':
      return claim(s, data);
    case 'ack':
      return acknowledge(s, data);
  }
}

function status(result, cmd) {
  if (['gate', 'emit', 'tick'].includes(cmd)) {
    const events = cmd === 'tick' ? result.events : [result];
    if (events.some(r => r.decision === 'BLOCK')) return 3;
    if (events.some(r => r.decision === 'INDETERMINATE')) return 4;
  }
  return ['match', 'resolve'].includes(cmd) && result.errors.length ? 4 : 0;
}
export function run(argv, env = {}) {
  let store;
  try {
    const { positionals, values: o } = options(argv);
    let [cmd, key] = positionals;
    if (o.version) return success({ version: contract.version });
    if (o.help || !cmd) cmd = 'contract';
    if (cmd === 'contract') return success(contract);
    const spec = Object.hasOwn(contract.commands, cmd) && contract.commands[cmd];
    need(spec, 'Unknown command');
    need(positionals.length === (spec.id ? 2 : 1), 'Unexpected or missing positional argument');
    const allowed = ['db', 'domain', 'scope', ...(spec.flags ?? []), ...(spec.input ? ['json', 'file'] : [])];
    for (const k of Object.keys(o)) need(allowed.includes(k), 'Option --' + k + ' is invalid for ' + cmd);
    if (cmd === 'convert-md') {
      need(o.markdown && !(o.markdown === '-' && o.file === '-'), 'Provide a separate --markdown file');
      const metadata = input(o);
      return success(convertMarkdown(readText(o.markdown, true), { source: basename(o.markdown), ...metadata }));
    }
    const data = spec.input ? input(o) : {};
    store = boundary(o, env, cmd);
    const readOnly = ['get', 'history', 'list', 'export', 'resolve', 'match', 'event', 'events', 'work'].includes(cmd);
    const call = () => route(store, cmd, key, o, data);
    const result = readOnly ? transaction(store.db, call, false) : call();
    return success(result, status(result, cmd));
  } catch (e) {
    let err = e;
    if (!(e instanceof Fault)) {
      if ([5, 6].includes(e.errcode)) err = new Fault('BUSY', 'Database is busy; retry the request', 5);
      else if (e.code === 'ERR_SQLITE_ERROR' && (e.errcode & 255) === 19) err = new Fault('INVALID', e.message);
      else if (e.code === 'ENOENT' || e.code === 'ERR_ENCODING_INVALID_ENCODED_DATA') err = new Fault('INPUT_IO', e
        .message);
      else err = new Fault('STORAGE', e.message, 1);
    }
    return { exit: err.exit, body: { protocol: 1, ok: false, error: { code: err.code, message: err.message } } };
  } finally { store?.db.close(); }
}

function success(result, exit = 0) { return { exit, body: { protocol: 1, ok: true, result } }; }
