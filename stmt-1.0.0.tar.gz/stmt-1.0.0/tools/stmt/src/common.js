import { createHash } from 'node:crypto';

export class Fault extends Error {
  constructor(code, message, exit = 2, details) {
    super(message);
    Object.assign(this, { code, exit, details });
  }
}
export function need(ok, message) {
  if (!ok) throw new Fault('INVALID', message);
}
export function conflict(message) { throw new Fault('CONFLICT', message, 5); }
export function missing() { throw new Fault('NOT_FOUND', 'Resource unavailable in this boundary', 6); }
export function object(value, name = 'input') {
  need(value !== null && typeof value === 'object' && !Array.isArray(value), name + ' must be an object');
  return value;
}
export function keys(value, allowed, name = 'input') {
  object(value, name);
  for (const k of Object.keys(value)) need(allowed.includes(k), 'Unknown ' + name + ' field: ' + k);
}
export function string(value, name, max = 512) {
  need(typeof value === 'string' && value.trim() !== '' && !value.includes('\0') &&
    value.isWellFormed() && [...value].length <= max, name + ' must be nonblank, valid Unicode, up to ' + max +
    ' code points');
  return value;
}
export function integer(value, name, min = 0, max = Number.MAX_SAFE_INTEGER) {
  need(Number.isSafeInteger(value) && value >= min && value <= max, name + ' must be an integer in range');
  return value;
}
export function id(value, name = 'id') {
  need(typeof value === 'string' && /^[a-zA-Z0-9][a-zA-Z0-9._:-]{0,127}$/.test(value), 'Invalid ' + name);
  return value;
}
export const statementId = value => string(value, 'statement ID', 1048576);
export function operation(value) {
  need(typeof value === 'string' && /^[a-z][a-z0-9_]*\.[a-z][a-z0-9_]*$/.test(value) && value.length <= 128,
    'Expected operation in resource.verb form');
  return value;
}
export function scopePath(value) {
  need(typeof value === 'string' && value.length <= 512 &&
    (value === '/' || /^(\/[a-zA-Z0-9][a-zA-Z0-9_-]*)+$/.test(value)), 'Invalid absolute context scope');
  return value;
}
export function visible(ancestor, here) {
  return ancestor === '/' || here === ancestor || here.startsWith(ancestor + '/');
}
export function stable(value) {
  return JSON.stringify(value, (_, x) => x && typeof x === 'object' && !Array.isArray(x) ?
    Object.fromEntries(Object.keys(x).sort().map(k => [k, x[k]])) : x);
}
export function digest(value) { return createHash('sha256').update(stable(value)).digest('hex'); }
export function order(a, b) {
  return a.priority - b.priority || b.scope.split('/').filter(Boolean).length - a.scope.split('/').filter(Boolean)
    .length ||
    (a.id < b.id ? -1 : Number(a.id > b.id));
}
export function transaction(db, fn, write = true) {
  db.exec(write ? 'BEGIN IMMEDIATE' : 'BEGIN');
  try {
    const value = fn();
    db.exec('COMMIT');
    return value;
  } catch (error) {
    if (db.isTransaction) db.exec('ROLLBACK');
    throw error;
  }
}
export const now = () => Math.floor(Date.now() / 1000);
