import { compile } from './cel.js';
import { calendar } from './schedule.js';
import { id, integer, keys, need, operation, stable, statementId, string, visible } from './common.js';

const timestamp = (n, label) => integer(n, label, 0, 253402300799);

function ruleDocument(rule) {
  if (rule === null) return null;
  keys(rule, ['effect', 'trigger', 'action'], 'rule');
  need(['BLOCK', 'ACT'].includes(rule.effect), 'Unknown effect');
  const t = rule.trigger;
  if (t?.kind === 'EVENT') {
    keys(t, ['kind', 'phase', 'operation'], 'event trigger');
    need(['BEFORE', 'AFTER'].includes(t.phase), 'Unknown hook phase');
    operation(t.operation);
  } else {
    need(t?.kind === 'SCHEDULE', 'Unknown trigger kind');
    if (t.mode === 'AT') {
      keys(t, ['kind', 'mode', 'at']);
      timestamp(t.at, 'at');
    } else {
      need(t.mode === 'EVERY', 'Unknown schedule mode');
      if ('interval_seconds' in t) {
        keys(t, ['kind', 'mode', 'interval_seconds', 'anchor_at']);
        integer(t.interval_seconds, 'interval_seconds', 1, 253402300799);
        timestamp(t.anchor_at, 'anchor_at');
      } else {
        keys(t, ['kind', 'mode', 'cron', 'timezone']);
        calendar(t.cron, t.timezone);
      }
    }
  }
  if (rule.effect === 'ACT') {
    keys(rule.action, ['operation'], 'action');
    operation(rule.action.operation);
  } else {
    need(t.kind === 'EVENT' && t.phase === 'BEFORE' && !('action' in rule),
      'BLOCK requires a BEFORE hook and no action');
  }
  return rule;
}
export function document(data) {
  keys(data, ['statement', 'owner', 'category', 'ttl_seconds', 'priority', 'evidence', 'conditionals', 'rule',
    'requires', 'enabled', 'override_key'
  ], 'statement');
  string(data.statement, 'statement');
  keys(data.owner, ['type', 'id'], 'owner');
  string(data.owner.type, 'owner.type', 128);
  string(data.owner.id, 'owner.id', 512);
  string(data.category, 'category', 256);
  const { ttl_seconds: ttl = null, priority = 2, evidence = [], conditionals = [], requires = [], enabled = true, rule =
    null } = data;
  if (ttl !== null) integer(ttl, 'ttl_seconds', 1, 253402300799);
  integer(priority, 'priority', 0, 4);
  need(typeof enabled === 'boolean', 'enabled must be Boolean');
  need(Array.isArray(evidence) && evidence.length <= 256, 'Expected an evidence list of up to 256 items');
  for (const entry of evidence) {
    string(entry?.ref, 'evidence.ref', 4096);
    if ('locator' in entry) string(entry.locator, 'evidence.locator', 4096);
  }
  need(Array.isArray(conditionals) && conditionals.length <= 64, 'Expected up to 64 CEL conditions');
  conditionals.forEach(compile);
  need(Array.isArray(requires) && requires.length <= 64 && new Set(requires).size === requires.length,
    'Invalid or duplicate prerequisites');
  requires.forEach(statementId);
  ruleDocument(rule);
  const override_key = data.override_key ?? null;
  if (override_key !== null) {
    id(override_key, 'override_key');
    need(rule === null, 'Only plain instructions may declare override_key');
  }
  need(requires.length === 0 || rule?.effect === 'ACT', 'Only ACT rules may require other statements');
  return {
    statement: data.statement,
    owner: data.owner,
    category: data.category,
    priority,
    ttl_seconds: ttl,
    evidence,
    conditionals,
    enabled,
    rule,
    override_key,
    requires: [...requires].sort()
  };
}
export function content(row) {
  const { statement, owner, category, priority, ttl_seconds, evidence, conditionals, enabled, rule, requires,
    override_key } = row;
  return { statement, owner, category, priority, ttl_seconds, evidence, conditionals, enabled, rule, requires,
    override_key };
}
export function validateGraph(rows) {
  const byId = new Map(rows.map(r => [r.id, r]));
  const pending = new Map(),
    children = new Map();
  for (const r of rows) {
    pending.set(r.id, r.requires.length);
    for (const key of r.requires) {
      const parent = byId.get(key);
      need(parent && visible(parent.scope, r.scope) && parent.rule?.effect === 'ACT' &&
        stable(parent.rule.trigger) === stable(r.rule.trigger),
        'Prerequisite must be a visible ACT with the same trigger');
      if (!children.has(key)) children.set(key, []);
      children.get(key).push(r.id);
    }
  }
  const queue = rows.filter(r => !r.requires.length).map(r => r.id);
  for (let i = 0; i < queue.length; i++) {
    for (const child of children.get(queue[i]) ?? []) {
      const n = pending.get(child) - 1;
      pending.set(child, n);
      if (!n) queue.push(child);
    }
  }
  need(queue.length === rows.length, 'Cyclic statement chain');
}
