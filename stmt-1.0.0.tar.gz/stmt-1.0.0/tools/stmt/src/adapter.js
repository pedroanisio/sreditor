import { run } from './command.js';
import { digest, Fault, id, need, object, operation, stable } from './common.js';

// A host supplies the trusted boundary and real operation implementations.
export class AgentHost {
  constructor({ db, domain, scope, handlers = {} }) {
    this.env = { STMT_DB: db, STMT_DOMAIN: domain, STMT_SCOPE: scope, STMT_POLICY_MODE: 'consume' };
    this.handlers = new Map(Object.entries(handlers));
    for (const [name, fn] of this.handlers) {
      operation(name);
      need(typeof fn === 'function', 'Handler must be a function');
    }
  }
  call(command, { key, data } = {}) {
    const args = [command];
    if (key !== undefined) args.push(key);
    if (data !== undefined) args.push('--json', JSON.stringify(data));
    const { body, exit } = run(args, this.env);
    if (!body.ok) throw new Fault(body.error.code, body.error.message, exit);
    return body.result;
  }
  instructions(context = {}) {
    const resolved = this.call('resolve', { data: { context } });
    return { ...resolved, complete: resolved.errors.length === 0 };
  }
  async perform({ id: request, operation: op, context = {}, cause = null }) {
    id(request, 'request ID');
    const key = digest(['host', this.env.STMT_DOMAIN, this.env.STMT_SCOPE, request]);
    return this.execute(key, op, context, cause, {});
  }
  async execute(key, op, ctx, cause, inputs) {
    operation(op);
    object(ctx);
    const gate = this.call('gate', { data: { id: 'before:' + key, operation: op, context: ctx, cause } });
    if (gate.decision !== 'ALLOW') return { status: gate.decision, gate };
    const afterId = 'after:' + key;
    let existing;
    try { existing = this.call('event', { key: afterId }); } catch (e) { if (e.code !== 'NOT_FOUND') throw e; }
    if (existing) {
      need(existing.input.cause === gate.event_id && existing.input.operation === op &&
        stable(existing.input.context) === stable(ctx), 'After-event identifier collision');
      return { status: 'succeeded', replayed: true, result: existing.input.result, gate, after: existing };
    }
    const handler = this.handlers.get(op);
    if (!handler) throw new Fault('UNBOUND_HANDLER', 'No registered handler for ' + op);
    // The external handler must deduplicate this key across crashes and concurrent retries.
    const result = (await handler({ idempotency_key: key, context: ctx, inputs })) ?? null;
    const after = this.call('emit', { data: { id: afterId, operation: op, context: ctx, cause: gate.event_id,
          result } });
    return { status: 'succeeded', replayed: false, result, gate, after };
  }
  async runNext(eventId, worker, leaseSeconds = 60) {
    const { item } = this.call('claim', { data: { event_id: eventId, worker, lease_seconds: leaseSeconds } });
    if (!item) return null;
    const origin = this.call('event', { key: eventId });
    const run = await this.execute(item.action_id, item.operation, origin.input.context, eventId, item.inputs);
    const succeeded = run.status === 'succeeded';
    const receipt = this.call('ack', {
      data: {
        action_id: item.action_id,
        token: item.token,
        status: succeeded ? 'succeeded' : 'failed',
        result: succeeded ? run.result : { decision: run.status, event_id: run.gate.event_id }
      }
    });
    return { item: item.statement_id, receipt, run };
  }
}
