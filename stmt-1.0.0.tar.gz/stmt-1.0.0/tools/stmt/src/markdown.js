import { createHash } from 'node:crypto';
import { id, keys, need, string } from './common.js';
import { document } from './model.js';

// Produce a reviewable bundle. Only an explicit import can write these records.
export function convertMarkdown(text, options) {
  keys(options, ['source', 'prefix', 'owner', 'category']);
  const source = string(options.source, 'source', 1024),
    prefix = id(options.prefix, 'prefix');
  const sha256 = createHash('sha256').update(text).digest('hex'),
    statements = [];
  const lines = text.replace(/^\uFEFF/, '').replaceAll('\r\n', '\n').split('\n');
  let start = 1,
    buffer = [],
    last = 1;

  function flush() {
    const statement = buffer.join('');
    if (statement.trim()) {
      const index = statements.length + 1;
      const key = id(prefix + '.' + String(index).padStart(4, '0'));
      const entry = document({
        statement,
        owner: options.owner,
        category: options.category,
        evidence: [{ ref: source, locator: 'lines ' + start + '–' + last, sha256 }]
      });
      statements.push({ id: key, expected_revision: 0, document: entry });
    }
    buffer = [];
  }
  lines.forEach((line, i) => {
    const n = i + 1;
    if (!line.trim()) { flush(); return; }
    const piece = buffer.length ? '\n' + line : line;
    for (const char of piece) {
      if (buffer.length === 512) flush();
      if (!buffer.length) start = n;
      buffer.push(char);
      last = n;
    }
  });
  flush();
  need(statements.length > 0 && statements.length <= 1000, 'Markdown must produce 1..1000 statements');
  return { source, sha256, statements };
}
