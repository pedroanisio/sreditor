#!/usr/bin/env node

import { run } from './command.js';

const { exit, body } = run(process.argv.slice(2), process.env);
process.stdout.write(JSON.stringify(body) + '\n');
process.exitCode = exit;
