import { integer, need, string } from './common.js';

const bounds = [
  [0, 59],
  [0, 23],
  [1, 31],
  [1, 12],
  [0, 7]
];
const names = [null, null, null, 'jan feb mar apr may jun jul aug sep oct nov dec', 'sun mon tue wed thu fri sat'];

function field(source, i) {
  const [min, max] = bounds[i];
  const set = new Set();
  const number = token => {
    if (names[i] && /^[a-z]{3}$/i.test(token)) {
      const pos = names[i].split(' ').indexOf(token.toLowerCase());
      need(pos >= 0, 'Unknown cron name');
      return pos + min;
    }
    need(/^\d+$/.test(token), 'Invalid cron field');
    return integer(Number(token), 'cron value', min, max);
  };
  for (const term of source.split(',')) {
    const match = /^([^/]+)(?:\/(\d+))?$/.exec(term);
    need(match, 'Invalid cron step');
    const step = integer(Number(match[2] ?? 1), 'cron step', 1, max + 1);
    const piece = match[1].split('-');
    let low = min,
      high = max;
    if (match[1] !== '*') {
      need(piece.length <= 2, 'Invalid cron range');
      low = number(piece[0]);
      high = piece.length === 2 ? number(piece[1]) : match[2] ? max : low;
    }
    need(low <= high, 'Descending cron range');
    for (let n = low; n <= high; n += step) set.add(i === 4 && n === 7 ? 0 : n);
  }
  return set;
}
const compiled = new Map();
export function calendar(expr, zone) {
  string(expr, 'cron', 128);
  string(zone, 'timezone', 128);
  need(!/^[+-]/.test(zone), 'Expected a named IANA time zone');
  const key = JSON.stringify([expr, zone]);
  if (compiled.has(key)) return compiled.get(key);
  const fields = expr.trim().split(/\s+/);
  need(fields.length === 5, 'Expected five cron fields');
  const sets = fields.map(field);
  let clock;
  try {
    clock = new Intl.DateTimeFormat('en-GB', {
      timeZone: zone,
      hourCycle: 'h23',
      hour: '2-digit',
      minute: '2-digit',
      day: '2-digit',
      month: '2-digit',
      weekday: 'short'
    });
  } catch { need(false, 'Unknown IANA time zone'); }
  const fn = slot => {
    const p = Object.fromEntries(clock.formatToParts(slot * 1000).map(x => [x.type, x.value]));
    const dow = names[4].split(' ').indexOf(p.weekday.toLowerCase());
    const day = sets[2].has(+p.day),
      weekday = sets[4].has(dow);
    const dayOK = fields[2].startsWith('*') || fields[4].startsWith('*') ? day && weekday : day || weekday;
    return sets[0].has(+p.minute) && sets[1].has(+p.hour) && sets[3].has(+p.month) && dayOK;
  };
  if (compiled.size >= 256) compiled.clear();
  compiled.set(key, fn);
  return fn;
}
export function slots(trigger, from, until, revisionStart) {
  const first = Math.max(from + 1, revisionStart);
  if (trigger.mode === 'AT') return trigger.at >= first && trigger.at <= until ? [trigger.at] : [];
  const result = [];
  if ('interval_seconds' in trigger) {
    const period = trigger.interval_seconds;
    const n = Math.max(0, Math.ceil((first - trigger.anchor_at) / period));
    for (let slot = trigger.anchor_at + n * period; slot <= until; slot += period) {
      need(result.length < 1000, 'More than 1000 slots; use a smaller window');
      result.push(slot);
    }
  } else {
    const due = calendar(trigger.cron, trigger.timezone);
    for (let slot = Math.ceil(first / 60) * 60; slot <= until; slot += 60)
      if (due(slot)) result.push(slot);
  }
  return result;
}
