import { runInNewContext } from 'node:vm';
import { Environment } from '../vendor/cel/lib/index.js';
import { Fault, need, object, string } from './common.js';

const env = new Environment().registerVariable('ctx', 'map<string, dyn>')
  .registerVariable('event', 'map<string, dyn>').registerVariable('scope', 'string').registerVariable('domain',
    'string');
const cache = new Map();
export function compile(source) {
  string(source, 'CEL expression', 2048);
  if (cache.has(source)) return cache.get(source);
  let parsed;
  try {
    parsed = env.parse(source);
    const checked = parsed.check();
    if (!checked.valid) throw checked.error;
    if (checked.type !== 'bool') throw new Error('condition must have static type bool');
  } catch (err) { throw new Fault('INVALID_CEL', err.message); }
  if (cache.size >= 512) cache.clear();
  cache.set(source, parsed);
  return parsed;
}

function convert(value, depth = 0) {
  need(depth <= 40, 'JSON context nesting exceeds 40');
  if (Array.isArray(value)) return value.map(x => convert(x, depth + 1));
  if (value !== null && typeof value === 'object') {
    return new Map(Object.entries(value).map(([k, v]) => [k, convert(v, depth + 1)]));
  }
  if (typeof value === 'number') {
    need(Number.isFinite(value) && (!Number.isInteger(value) || Number.isSafeInteger(value)), 'Unsafe JSON number');
    if (Number.isInteger(value)) return BigInt(value);
  }
  return value;
}
export function bindings(ctx, event, scope, domain) {
  return { ctx: convert(object(ctx, 'context')), event: convert(event), scope, domain };
}
export function matches(conditions, vars) {
  let failure;
  for (const expr of conditions) {
    try {
      const fn = compile(expr);
      const answer = runInNewContext('fn(vars)', { fn, vars }, { timeout: 150 });
      need(typeof answer === 'boolean', 'Condition returned a non-Boolean');
      if (!answer) return { match: false };
    } catch (error) { failure ??= { expression: expr, message: error.message }; }
  }
  return failure ? { error: failure } : { match: true };
}
