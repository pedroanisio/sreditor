import { DatabaseSync } from 'node:sqlite';
import { readFileSync, existsSync, openSync, closeSync } from 'node:fs';
import { conflict, Fault, id, integer, keys, missing, need, now, order, scopePath, stable, statementId, transaction,
  visible } from './common.js';
import { content, document, validateGraph } from './model.js';

const script = file => readFileSync(new URL('../sql/' + file, import.meta.url), 'utf8');
const baseSQL = script('statement-store.sql'),
  engineSQL = script('engine.sql');
const table = (db, name) => !!db.prepare("SELECT 1 FROM sqlite_schema WHERE type='table' AND name=?").get(name);
const identity = db => db.prepare('SELECT domain,version FROM engine_meta WHERE singleton=1').get();
export function openStore(path, domain, scope, init = false, adopt = false, register = false) {
  id(domain, 'domain');
  scopePath(scope);
  need(typeof path === 'string' && path.length > 0 && path !== ':memory:', 'A persistent --db path is required');
  if (!init && !existsSync(path)) missing();
  if (init) need(scope === '/', 'Initialize at the domain root');
  if (init && !existsSync(path)) {
    try { closeSync(openSync(path, 'wx', 0o600)); } catch (e) { if (e.code !== 'EEXIST') throw e; }
  }
  const db = new DatabaseSync(path);
  try {
    db.exec('PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000; PRAGMA trusted_schema=OFF;');
    if (!table(db, 'engine_meta')) {
      need(init, 'Initialize the database with stmt init');
      const legacy = table(db, 'statement_revisions');
      need(legacy || !db.prepare("SELECT 1 FROM sqlite_schema WHERE name NOT LIKE 'sqlite_%'").get(),
        'Unrecognized database');
      need(!legacy || adopt || !db.prepare('SELECT 1 FROM statement_revisions LIMIT 1').get(),
        'Use --adopt to attach existing unscoped revisions to this domain at /');
      db.exec(baseSQL);
      transaction(db, () => {
        db.exec(engineSQL);
        db.prepare('INSERT OR IGNORE INTO engine_meta VALUES(1,?,1)').run(domain);
        db.exec("INSERT OR IGNORE INTO locations SELECT DISTINCT statement_id,'/' FROM statement_revisions");
        if (legacy)
          for (const row of select(db, true)) {
            try { statementId(row.id);
              document(content(row)); } catch (e) { throw new Fault('LEGACY_INVALID', 'Revise v2 head ' + row.id +
                ' before adoption: ' + e.message); }
          }
      });
    }
    const owner = identity(db);
    if (owner?.domain !== domain) missing();
    need(owner.version === 1, 'Unsupported engine schema version');
    if (register) transaction(db, () => {
      const parent = scope.slice(0, scope.lastIndexOf('/')) || '/';
      if (!db.prepare('SELECT 1 FROM scopes WHERE path=?').get(parent)) missing();
      db.prepare('INSERT OR IGNORE INTO scopes VALUES(?)').run(scope);
    });
    if (!db.prepare('SELECT 1 FROM scopes WHERE path=?').get(scope)) missing();
    return { db, domain, scope };
  } catch (e) { db.close(); throw e; }
}

function decode(r) {
  return {
    id: r.statement_id,
    revision: r.revision,
    revised_at: r.revised_at,
    expires_at: r.expires_at,
    scope: r.scope,
    statement: r.statement,
    owner: { type: r.owner_type, id: r.owner_id },
    category: r.category,
    priority: r.priority,
    ttl_seconds: r.ttl_seconds,
    evidence: JSON.parse(r.evidence),
    conditionals: JSON.parse(r.conditionals),
    rule: JSON.parse(r.rule),
    requires: JSON.parse(r.deps ?? '[]'),
    enabled: r.enabled !== 0,
    override_key: r.override_key
  };
}

function select(db, latest, where = '', args = []) {
  const view = latest ? 'latest_statements' : 'statement_snapshots';
  return db.prepare(`SELECT s.*, l.scope, o.enabled, o.requires AS deps, o.override_key
    FROM ${view} s JOIN locations l USING(statement_id)
    LEFT JOIN revision_options o USING(statement_id,revision) ${where}`).all(...args).map(decode);
}
export function heads(store, all = false) {
  const rows = select(store.db, true);
  return (all ? rows : rows.filter(r => visible(r.scope, store.scope))).sort(order);
}
export function active(store, time = now()) {
  return heads(store).filter(r => r.enabled && (r.expires_at === null || time < r.expires_at));
}
export function get(store, key, revision, history = false) {
  statementId(key);
  if (revision !== undefined) integer(revision, 'revision', 1);
  const args = revision === undefined ? [key] : [key, revision];
  const rows = select(store.db, !history && revision === undefined, 'WHERE s.statement_id=?' +
    (args.length === 2 ? ' AND s.revision=?' : '') + ' ORDER BY s.revision', args);
  if (!rows.length || !visible(rows[0].scope, store.scope)) missing();
  return history ? rows : rows[0];
}

function append(store, item, allowSame) {
  keys(item, ['id', 'expected_revision', 'document'], 'bundle entry');
  const key = statementId(item.id),
    expected = integer(item.expected_revision, 'expected_revision');
  const data = document(item.document),
    db = store.db;
  const current = select(db, true, 'WHERE s.statement_id=?', [key])[0];
  if (current && current.scope !== store.scope) conflict('ID unavailable for writing at this scope');
  if (allowSame && current && stable(content(current)) === stable(data)) return { id: key, revision: current.revision,
    changed: false };
  if ((current?.revision ?? 0) !== expected) conflict('Revision conflict for ' + key);
  const rev = expected + 1;
  db.prepare('INSERT OR IGNORE INTO locations VALUES(?,?)').run(key, store.scope);
  db.prepare(`INSERT INTO statement_snapshots(statement_id,revision,statement,owner_type,owner_id,
    category,priority,ttl_seconds,evidence,conditionals,rule) VALUES(?,?,?,?,?,?,?,?,?,?,?)`)
    .run(key, rev, data.statement, data.owner.type, data.owner.id, data.category, data.priority, data.ttl_seconds,
      stable(data.evidence), stable(data.conditionals), data.rule === null ? null : stable(data.rule));
  db.prepare('INSERT INTO revision_options VALUES(?,?,?,?,?)').run(key, rev, Number(data.enabled), stable(data
    .requires), data.override_key);
  return { id: key, revision: rev, changed: true };
}
export function save(store, items, allowSame = false) {
  need(Array.isArray(items) && items.length > 0 && items.length <= 1000, 'Expected 1..1000 statement entries');
  return transaction(store.db, () => {
    need(new Set(items.map(x => x?.id)).size === items.length, 'Duplicate IDs in bundle');
    const result = items.map(x => append(store, x, allowSame));
    validateGraph(heads(store, true));
    return result;
  });
}
export function exportScope(store) {
  return {
    statements: heads(store).filter(r => r.scope === store.scope).map(r => ({
      id: r.id,
      expected_revision: 0,
      document: content(r)
    }))
  };
}
