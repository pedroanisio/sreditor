CREATE TABLE IF NOT EXISTS engine_meta (
    singleton INTEGER PRIMARY KEY CHECK(singleton=1), domain TEXT NOT NULL, version INTEGER NOT NULL
) STRICT;
CREATE TABLE IF NOT EXISTS locations (statement_id TEXT PRIMARY KEY, scope TEXT NOT NULL) STRICT;
CREATE TRIGGER IF NOT EXISTS locate_legacy_statement AFTER INSERT ON statement_revisions
BEGIN
    INSERT OR IGNORE INTO locations VALUES(NEW.statement_id,'/');
END;
CREATE TABLE IF NOT EXISTS scopes (path TEXT PRIMARY KEY) STRICT;
INSERT OR IGNORE INTO scopes VALUES('/');
CREATE TABLE IF NOT EXISTS revision_options (
    statement_id TEXT NOT NULL, revision INTEGER NOT NULL, enabled INTEGER NOT NULL CHECK(enabled IN (0,1)),
    requires TEXT NOT NULL CHECK(json_type(requires)='array'), override_key TEXT,
    PRIMARY KEY(statement_id,revision),
    FOREIGN KEY(statement_id,revision) REFERENCES statement_revisions(statement_id,revision)
) STRICT;
CREATE TABLE IF NOT EXISTS events (
    scope TEXT NOT NULL, id TEXT NOT NULL, input TEXT NOT NULL, decision TEXT NOT NULL,
    root TEXT NOT NULL, depth INTEGER NOT NULL, slot INTEGER, created_at INTEGER NOT NULL,
    sequence INTEGER NOT NULL CHECK(sequence>0), PRIMARY KEY(scope,id), UNIQUE(scope,sequence)
) STRICT;
CREATE INDEX IF NOT EXISTS events_slots ON events(scope,slot) WHERE slot IS NOT NULL;
CREATE TABLE IF NOT EXISTS work_items (
    scope TEXT NOT NULL, event_id TEXT NOT NULL, statement_id TEXT NOT NULL, revision INTEGER NOT NULL,
    action_id TEXT NOT NULL UNIQUE, operation TEXT NOT NULL, rank INTEGER NOT NULL, requires TEXT NOT NULL,
    state TEXT NOT NULL CHECK(state IN ('waiting','ready','leased','succeeded','failed','cancelled')),
    worker TEXT, token TEXT, lease_until INTEGER, result TEXT,
    PRIMARY KEY(scope,event_id,statement_id),
    FOREIGN KEY(scope,event_id) REFERENCES events(scope,id),
    FOREIGN KEY(statement_id,revision) REFERENCES statement_revisions(statement_id,revision)
) STRICT;
CREATE INDEX IF NOT EXISTS work_ready ON work_items(scope,state,event_id,rank);
CREATE TRIGGER IF NOT EXISTS event_no_update BEFORE UPDATE ON events
BEGIN SELECT RAISE(ABORT,'event decisions are immutable'); END;
CREATE TRIGGER IF NOT EXISTS event_no_delete BEFORE DELETE ON events
BEGIN SELECT RAISE(ABORT,'event journal is retained'); END;
CREATE TRIGGER IF NOT EXISTS event_no_replace BEFORE INSERT ON events
WHEN EXISTS(SELECT 1 FROM events WHERE scope=NEW.scope AND (id=NEW.id OR sequence=NEW.sequence))
BEGIN SELECT RAISE(ABORT,'event identity is immutable'); END;
CREATE TRIGGER IF NOT EXISTS location_no_update BEFORE UPDATE ON locations
BEGIN SELECT RAISE(ABORT,'statement scope is immutable'); END;
CREATE TRIGGER IF NOT EXISTS location_no_delete BEFORE DELETE ON locations
BEGIN SELECT RAISE(ABORT,'statement scope is retained'); END;
CREATE TRIGGER IF NOT EXISTS location_existing BEFORE INSERT ON locations
WHEN EXISTS(SELECT 1 FROM locations WHERE statement_id=NEW.statement_id)
BEGIN SELECT RAISE(IGNORE); END;
CREATE TRIGGER IF NOT EXISTS options_no_update BEFORE UPDATE ON revision_options
BEGIN SELECT RAISE(ABORT,'revision options are immutable'); END;
CREATE TRIGGER IF NOT EXISTS options_no_delete BEFORE DELETE ON revision_options
BEGIN SELECT RAISE(ABORT,'revision options are retained'); END;
CREATE TRIGGER IF NOT EXISTS options_no_replace BEFORE INSERT ON revision_options
WHEN EXISTS(SELECT 1 FROM revision_options WHERE statement_id=NEW.statement_id AND revision=NEW.revision)
BEGIN SELECT RAISE(ABORT,'revision options are immutable'); END;
