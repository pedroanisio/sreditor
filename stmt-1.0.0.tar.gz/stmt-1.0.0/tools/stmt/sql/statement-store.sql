-- Versioned statement store, schema v2. SQLite 3.38+ with JSON support.
-- Initialize, upgrade v1 or reapply v2: sqlite3 -bail statements.db < statement-store.sql
-- Enable foreign keys on every writer connection, before starting a transaction.
-- Priority 0 is highest, 4 is lowest. A NULL TTL gives an open-ended revision.
-- The limit on statement text is 1..512 Unicode code points, including spaces.
-- Embedded NUL is rejected because SQLite length(TEXT) stops at the first NUL.
-- V1 upgrade: an oversized latest revision stops the upgrade. Find it with:
--   SELECT statement_id, revision FROM latest_statements
--   WHERE length(statement) NOT BETWEEN 1 AND 512 OR instr(statement, char(0)) > 0;
-- Append a compliant revision in v1, then rerun this file. Older history is preserved.

PRAGMA foreign_keys = ON;
BEGIN IMMEDIATE;

CREATE TEMP TABLE statement_model_version_guard (
    version INTEGER CONSTRAINT unsupported_statement_store_version CHECK (version IN (0, 1, 2))
);
INSERT OR ROLLBACK INTO statement_model_version_guard SELECT user_version FROM pragma_user_version;
DROP TABLE temp.statement_model_version_guard;

-- One row is a complete revision. The permanent ID can be a caller-assigned
-- key such as 'delivery.editable-package'. The CLI exposes UTC times as RFC 3339.
CREATE TABLE IF NOT EXISTS statement_revisions (
    statement_id  TEXT    NOT NULL CHECK (trim(statement_id, char(9, 10, 11, 12, 13, 32)) <> ''),
    revision      INTEGER NOT NULL CHECK (revision >= 1),
    revised_at    INTEGER NOT NULL DEFAULT (unixepoch())
                          CHECK (revised_at BETWEEN 0 AND 253402300799),
    ttl_seconds   INTEGER,
    expires_at    INTEGER GENERATED ALWAYS AS (revised_at + ttl_seconds) VIRTUAL,
    statement     TEXT    NOT NULL CHECK (trim(statement, char(9, 10, 11, 12, 13, 32)) <> ''),
    owner_type    TEXT    NOT NULL CHECK (trim(owner_type, char(9, 10, 11, 12, 13, 32)) <> ''),
    owner_id      TEXT    NOT NULL CHECK (trim(owner_id, char(9, 10, 11, 12, 13, 32)) <> ''),
    category      TEXT    NOT NULL CHECK (trim(category, char(9, 10, 11, 12, 13, 32)) <> ''),
    priority      INTEGER NOT NULL DEFAULT 2 CHECK (priority BETWEEN 0 AND 4),
    evidence      TEXT    NOT NULL DEFAULT '[]'
                          CHECK (json_valid(evidence) AND json_type(evidence) = 'array'),
    conditionals  TEXT    NOT NULL DEFAULT '[]'
                          CHECK (json_valid(conditionals) AND json_type(conditionals) = 'array'),
    PRIMARY KEY (statement_id, revision),
    -- Keep the optional expiration within the last second of UTC year 9999.
    CHECK (ttl_seconds IS NULL OR ttl_seconds BETWEEN 1 AND 253402300799 - revised_at)
) STRICT, WITHOUT ROWID;

-- Check current v1 heads under the same write lock that installs the new limit.
CREATE TEMP TABLE statement_text_upgrade_guard (
    invalid INTEGER CONSTRAINT append_a_compliant_latest_revision_in_v1 CHECK (invalid = 0)
);
INSERT OR ROLLBACK INTO statement_text_upgrade_guard
SELECT 1 FROM statement_revisions AS s
WHERE (length(s.statement) NOT BETWEEN 1 AND 512 OR instr(s.statement, char(0)) > 0)
  AND NOT EXISTS (
      SELECT 1 FROM statement_revisions AS n
      WHERE n.statement_id = s.statement_id AND n.revision > s.revision
  )
LIMIT 1;
DROP TABLE temp.statement_text_upgrade_guard;

-- Applies equally to legacy direct writers and the new full-snapshot write view.
CREATE TRIGGER IF NOT EXISTS statement_revision_text_limit
BEFORE INSERT ON statement_revisions
WHEN length(NEW.statement) NOT BETWEEN 1 AND 512 OR instr(NEW.statement, char(0)) > 0
BEGIN
    SELECT RAISE(ABORT, 'statement must contain 1 to 512 Unicode code points and no NUL');
END;

-- Create inserts revision 1. Revise inserts the caller's expected_revision + 1.
-- The check runs inside the write, so stale and concurrent writers cannot
-- both append to the same base revision. Revisions may share a timestamp.
CREATE TRIGGER IF NOT EXISTS statement_revision_sequence
BEFORE INSERT ON statement_revisions
BEGIN
    SELECT RAISE(ABORT, 'revision conflict: expected the next revision')
    WHERE NEW.revision <> (
        SELECT coalesce(max(revision), 0) + 1
        FROM statement_revisions
        WHERE statement_id = NEW.statement_id
    );
    SELECT RAISE(ABORT, 'revision timestamp precedes its predecessor')
    WHERE NEW.revised_at < (
        SELECT revised_at FROM statement_revisions
        WHERE statement_id = NEW.statement_id AND revision = NEW.revision - 1
    );
    SELECT RAISE(ABORT, 'revision timestamp is in the future')
    WHERE NEW.revised_at > unixepoch();
END;

-- CHECK validates the outer arrays first. This trigger then checks their
-- contents. The CLI implementation must compile each CEL expression against
-- ctx: map<string, dyn> and require a Boolean result before writing. The SQL
-- stores the source text for inspection and replay.
CREATE TRIGGER IF NOT EXISTS statement_revision_items
AFTER INSERT ON statement_revisions
BEGIN
    SELECT RAISE(ABORT, 'evidence item needs a text ref and an optional text locator')
    WHERE EXISTS (
        SELECT 1 FROM json_each(NEW.evidence) AS item
        WHERE CASE WHEN item.type = 'object' THEN
            json_type(item.value, '$.ref') IS NOT 'text'
            OR trim(json_extract(item.value, '$.ref'), char(9, 10, 11, 12, 13, 32)) = ''
            OR coalesce(json_type(item.value, '$.locator'), 'text') <> 'text'
        ELSE 1 END
    );
    SELECT RAISE(ABORT, 'each conditional must be a nonempty CEL source string')
    WHERE EXISTS (
        SELECT 1 FROM json_each(NEW.conditionals) AS item
        WHERE item.type <> 'text' OR trim(item.value, char(9, 10, 11, 12, 13, 32)) = ''
    );
END;

CREATE TRIGGER IF NOT EXISTS statement_revision_no_update
BEFORE UPDATE ON statement_revisions
BEGIN
    SELECT RAISE(ABORT, 'revisions are immutable: append a revision');
END;

CREATE TRIGGER IF NOT EXISTS statement_revision_no_delete
BEFORE DELETE ON statement_revisions
BEGIN
    SELECT RAISE(ABORT, 'revision history is retained');
END;

-- An optional rule belongs to exactly one immutable revision. The public
-- statement_snapshots view below writes the rule and its parent in one statement.
CREATE TABLE IF NOT EXISTS statement_revision_rules (
    statement_id      TEXT NOT NULL,
    revision          INTEGER NOT NULL,
    rule              TEXT NOT NULL CHECK (json_valid(rule) AND json_type(rule) = 'object'),
    effect            TEXT AS (rule ->> '$.effect') VIRTUAL NOT NULL CHECK (effect IN ('BLOCK','ACT')),
    trigger_kind      TEXT AS (rule ->> '$.trigger.kind') VIRTUAL NOT NULL
                           CHECK (trigger_kind IN ('EVENT','SCHEDULE')),
    hook_phase        TEXT AS (rule ->> '$.trigger.phase') VIRTUAL,
    trigger_operation TEXT AS (rule ->> '$.trigger.operation') VIRTUAL,
    schedule_mode     TEXT AS (rule ->> '$.trigger.mode') VIRTUAL,
    action_operation  TEXT AS (rule ->> '$.action.operation') VIRTUAL,
    PRIMARY KEY (statement_id, revision),
    FOREIGN KEY (statement_id, revision) REFERENCES statement_revisions(statement_id, revision)
        DEFERRABLE INITIALLY DEFERRED,
    CHECK (json_type(rule, '$.trigger') IS 'object'),
    CHECK (CASE effect WHEN 'ACT' THEN json_type(rule, '$.action') IS 'object'
                    AND json_type(rule, '$.action.operation') IS 'text'
                       ELSE json_type(rule, '$.action') IS NULL END),
    CHECK (effect <> 'BLOCK' OR (trigger_kind = 'EVENT' AND hook_phase IS 'BEFORE')),
    CHECK ((CASE
        WHEN trigger_kind = 'EVENT' THEN hook_phase IN ('BEFORE','AFTER')
            AND json_type(rule, '$.trigger.operation') IS 'text'
        WHEN schedule_mode = 'AT' THEN json_type(rule, '$.trigger.at') IS 'integer'
            AND (rule ->> '$.trigger.at') BETWEEN 0 AND 253402300799
        WHEN schedule_mode = 'EVERY' AND json_type(rule, '$.trigger.interval_seconds') IS NOT NULL THEN
            json_type(rule, '$.trigger.interval_seconds') IS 'integer'
            AND (rule ->> '$.trigger.interval_seconds') BETWEEN 1 AND 253402300799
            AND json_type(rule, '$.trigger.anchor_at') IS 'integer'
            AND (rule ->> '$.trigger.anchor_at') BETWEEN 0 AND 253402300799
        WHEN schedule_mode = 'EVERY' THEN json_type(rule, '$.trigger.cron') IS 'text'
            AND length(trim(rule ->> '$.trigger.cron', char(9,10,11,12,13,32))) > 0
            AND json_type(rule, '$.trigger.timezone') IS 'text'
            AND length(trim(rule ->> '$.trigger.timezone', char(9,10,11,12,13,32))) > 0
        ELSE 0 END) IS TRUE)
) STRICT, WITHOUT ROWID;

CREATE TRIGGER IF NOT EXISTS statement_rule_seal BEFORE INSERT ON statement_revision_rules
BEGIN
    SELECT RAISE(ABORT, 'revision conflict: rule is immutable; append the next revision')
    WHERE EXISTS (SELECT 1 FROM statement_revisions
                  WHERE statement_id = NEW.statement_id AND revision = NEW.revision)
       OR EXISTS (SELECT 1 FROM statement_revision_rules
                  WHERE statement_id = NEW.statement_id AND revision = NEW.revision);
END;

CREATE TRIGGER IF NOT EXISTS statement_rule_shape AFTER INSERT ON statement_revision_rules
BEGIN
    SELECT RAISE(ABORT, 'duplicate rule key')
    WHERE EXISTS (SELECT 1 FROM json_tree(NEW.rule) GROUP BY parent, key HAVING count(*) > 1);
    SELECT RAISE(ABORT, 'unexpected rule, trigger or action field')
    WHERE EXISTS (SELECT 1 FROM json_each(NEW.rule) WHERE key NOT IN ('effect','trigger','action'))
       OR EXISTS (SELECT 1 FROM json_each(NEW.rule, '$.action') WHERE key <> 'operation')
       OR EXISTS (
           SELECT 1 FROM json_each(NEW.rule, '$.trigger') WHERE key NOT IN (
               SELECT value FROM json_each(CASE
                   WHEN NEW.trigger_kind = 'EVENT' THEN '["kind","phase","operation"]'
                   WHEN NEW.schedule_mode = 'AT' THEN '["kind","mode","at"]'
                   WHEN json_type(NEW.rule, '$.trigger.interval_seconds') IS NOT NULL
                       THEN '["kind","mode","interval_seconds","anchor_at"]'
                   ELSE '["kind","mode","cron","timezone"]' END)
           )
       );
    -- The stored operation is resource.verb, with canonical lowercase identifiers.
    SELECT RAISE(ABORT, 'operation must be a lowercase resource.verb')
    WHERE EXISTS (
        SELECT 1 FROM (SELECT NEW.trigger_operation AS op UNION ALL SELECT NEW.action_operation)
        WHERE op IS NOT NULL AND (op NOT GLOB '[a-z]*.[a-z]*' OR op GLOB '*[^a-z0-9_.]*'
            OR instr(substr(op, instr(op, '.') + 1), '.') > 0 OR instr(op, char(0)) > 0)
    );
END;

CREATE TRIGGER IF NOT EXISTS statement_rule_no_update BEFORE UPDATE ON statement_revision_rules
BEGIN SELECT RAISE(ABORT, 'rule is immutable: append a new statement revision'); END;
CREATE TRIGGER IF NOT EXISTS statement_rule_no_delete BEFORE DELETE ON statement_revision_rules
BEGIN SELECT RAISE(ABORT, 'rule history is retained'); END;

CREATE VIEW IF NOT EXISTS statement_snapshots AS
SELECT s.*, r.rule FROM statement_revisions AS s
LEFT JOIN statement_revision_rules AS r USING (statement_id, revision);

CREATE TRIGGER IF NOT EXISTS statement_snapshot_append INSTEAD OF INSERT ON statement_snapshots
BEGIN
    INSERT INTO statement_revision_rules (statement_id, revision, rule)
    SELECT NEW.statement_id, NEW.revision, NEW.rule WHERE NEW.rule IS NOT NULL;
    INSERT INTO statement_revisions (
        statement_id, revision, revised_at, ttl_seconds, statement, owner_type,
        owner_id, category, priority, evidence, conditionals
    ) VALUES (
        NEW.statement_id, NEW.revision, coalesce(NEW.revised_at, unixepoch()),
        NEW.ttl_seconds, NEW.statement, NEW.owner_type, NEW.owner_id, NEW.category,
        coalesce(NEW.priority, 2), coalesce(NEW.evidence, '[]'), coalesce(NEW.conditionals, '[]')
    );
    -- An outer INSERT OR IGNORE must also preserve snapshot atomicity.
    SELECT RAISE(ABORT, 'incomplete statement snapshot') WHERE NOT EXISTS (
        SELECT 1 FROM statement_snapshots WHERE statement_id = NEW.statement_id
          AND revision = NEW.revision AND rule IS NEW.rule
    );
END;

-- Resolve the latest revision before applying expiry or any other filters.
-- Replace the two v1 views so get/list include the optional rule.
DROP VIEW IF EXISTS unexpired_statements;
DROP VIEW IF EXISTS latest_statements;
CREATE VIEW latest_statements AS
SELECT s.* FROM statement_snapshots AS s
WHERE NOT EXISTS (
    SELECT 1 FROM statement_revisions AS newer
    WHERE newer.statement_id = s.statement_id AND newer.revision > s.revision
);

CREATE VIEW unexpired_statements AS
SELECT * FROM latest_statements
WHERE expires_at IS NULL OR unixepoch() < expires_at;

-- A receipt records the matching rule revision. The key excludes revision so
-- a retry after an edit still resolves to the first receipt. Use a namespaced
-- source event ID or a canonical scheduled UTC slot as occurrence_id.
CREATE TABLE IF NOT EXISTS rule_occurrences (
    statement_id  TEXT NOT NULL,
    occurrence_id TEXT NOT NULL CHECK (trim(occurrence_id, char(9,10,11,12,13,32)) <> ''
                                       AND instr(occurrence_id, char(0)) = 0),
    revision      INTEGER NOT NULL,
    recorded_at   INTEGER NOT NULL DEFAULT (unixepoch()) CHECK (recorded_at BETWEEN 0 AND 253402300799),
    PRIMARY KEY (statement_id, occurrence_id),
    FOREIGN KEY (statement_id, revision) REFERENCES statement_revision_rules(statement_id, revision)
) STRICT, WITHOUT ROWID;

CREATE TRIGGER IF NOT EXISTS rule_occurrence_claim BEFORE INSERT ON rule_occurrences
BEGIN
    SELECT RAISE(IGNORE) WHERE EXISTS (
        SELECT 1 FROM rule_occurrences
        WHERE statement_id = NEW.statement_id AND occurrence_id = NEW.occurrence_id
    );
    SELECT RAISE(ABORT, 'receipt requires a current unexpired rule')
    WHERE NOT EXISTS (SELECT 1 FROM unexpired_statements
                      WHERE statement_id = NEW.statement_id AND revision = NEW.revision AND rule IS NOT NULL);
END;
CREATE TRIGGER IF NOT EXISTS rule_occurrence_no_update BEFORE UPDATE ON rule_occurrences
BEGIN SELECT RAISE(ABORT, 'occurrence receipts are immutable'); END;
CREATE TRIGGER IF NOT EXISTS rule_occurrence_no_delete BEFORE DELETE ON rule_occurrences
BEGIN SELECT RAISE(ABORT, 'occurrence history is retained'); END;

PRAGMA user_version = 2;
COMMIT;

-- Parameterized write for a full snapshot. Pass expected_revision = 0 for
-- create, or the revision supplied by the caller for revise. Encode both
-- lists as JSON arrays. Bind NULL for an open-ended TTL or a plain statement's rule.
-- INSERT INTO statement_snapshots (
--     statement_id, revision, statement, owner_type, owner_id,
--     category, priority, ttl_seconds, evidence, conditionals, rule
-- ) VALUES (
--     :id, :expected_revision + 1, :statement, :owner_type, :owner_id,
--     :category, :priority, :ttl_seconds, :evidence, :conditionals, :rule
-- );
--
-- CLI read paths (use bound parameters):
-- get:     SELECT * FROM latest_statements WHERE statement_id = :id;
-- history: SELECT * FROM statement_snapshots WHERE statement_id = :id ORDER BY revision;
-- list:    SELECT * FROM unexpired_statements ORDER BY priority, statement_id;
-- match:   start with list (optionally filtered by owner or category), then
--          evaluate conditionals against ctx in CEL. [] matches any context.
--          Return true matches in list order and report evaluation errors.
--
-- Example rule values (timestamps in stored rule JSON are UTC Unix seconds):
-- {"effect":"BLOCK","trigger":{"kind":"EVENT","phase":"BEFORE","operation":"code.write"}}
-- {"effect":"ACT","trigger":{"kind":"EVENT","phase":"AFTER","operation":"code.write"},"action":{"operation":"code.check"}}
-- {"effect":"ACT","trigger":{"kind":"SCHEDULE","mode":"AT","at":1793923200},"action":{"operation":"code.check"}}
-- {"effect":"ACT","trigger":{"kind":"SCHEDULE","mode":"EVERY","interval_seconds":21600,"anchor_at":0},"action":{"operation":"code.check"}}
-- {"effect":"ACT","trigger":{"kind":"SCHEDULE","mode":"EVERY","cron":"0 9 * * 1-5","timezone":"America/Sao_Paulo"},"action":{"operation":"code.check"}}
--
-- Runtime contract: validate five-field cron and IANA time zones, type-check
-- CEL, and bind named operations in the CLI. A BEFORE hook waits for a decision:
-- any matching BLOCK vetoes the operation across priorities. Evaluate gates
-- before dispatching any ACT. AFTER follows a successful operation. A due
-- slot must be at or after revised_at and earlier than expires_at, when set.
-- An elapsed slot is anchor_at + n * interval_seconds for integer n >= 0.
-- A calendar slot resolves to a UTC instant in the configured zone. Claim only
-- due slots for the current unexpired revision. Runs never renew the TTL.
-- On first match, write a receipt. On retry, read the pinned revision and use
-- (statement_id, occurrence_id) as the handler's idempotency key.
