import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { AgentHost } from '../src/adapter.js';
import { run } from '../src/command.js';

const dir = mkdtempSync(join(tmpdir(), 'stmt-demo-'));
const db = join(dir, 'rules.sqlite');
const env = { STMT_DB: db, STMT_DOMAIN: 'studio', STMT_SCOPE: '/' };

function admin(args) {
  const r = run(args, env);
  if (!r.body.ok) throw new Error(r.body.error.message);
}

function loadFile(file) {
  admin(['import', '--json', readFileSync(new URL(file, import.meta.url), 'utf8')]);
}
try {
  admin(['init']);
  loadFile('domain.json');
  admin(['scope-add', '--scope', '/repo']);
  env.STMT_SCOPE = '/repo';
  loadFile('repository.json');
  const host = new AgentHost({
    db,
    domain: 'studio',
    scope: '/repo',
    handlers: {
      'code.write': () => ({ files: 1 }),
      'code.check': () => ({ passed: 17 }),
      'report.publish': ({ inputs }) => ({ published: inputs['write.test'].result.passed })
    }
  });
  const denied = await host.perform({ id: 'demo-denied', operation: 'code.write', context: { branch: 'main',
      reviewed: false } });
  const allowed = await host.perform({ id: 'demo-allowed', operation: 'code.write', context: { branch: 'main',
      reviewed: true } });
  const chain = [];
  let step;
  while ((step = await host.runNext(allowed.after.event_id, 'demo-worker'))) {
    chain.push({ statement: step.item, result: step.run.result });
  }
  process.stdout.write(JSON.stringify({ denied: denied.status, allowed: allowed.gate.decision, chain }, null, 2) +
  '\n');
} finally { rmSync(dir, { recursive: true, force: true }); }
