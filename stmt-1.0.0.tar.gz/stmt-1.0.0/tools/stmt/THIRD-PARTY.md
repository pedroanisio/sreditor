# Third-party software

The package vendors the runtime JavaScript sources of @marcbachmann/cel-js at tag v8.0.0, commit 86cd97216a1cbb522eda81aaa0221c245d5913d7. The original MIT notice is included at vendor/cel/LICENSE. The files were verified against their upstream Git blob IDs.

https://github.com/marcbachmann/cel-js/tree/v8.0.0
