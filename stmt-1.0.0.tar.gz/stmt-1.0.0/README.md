# stmt

Part of [super-tools](../../README.md). Launcher: `bin/stmt`; `stmt --help` renders its manpage.

Use `stmt` as the policy store for an agent runtime. Agents load relevant instructions with `resolve`, ask `gate` for a decision before an operation, and submit an `emit` event after it succeeds. The host adapter implements that lifecycle for named handlers. SQLite stores revisions, decisions and work across restarts.

## Source of truth

A store is the single source of truth for an agent runtime's rules. Read a rule in one of two ways, never from a hand-kept copy:

1. **From the database.** Use `stmt list --category C` for a category, `stmt get ID` for one rule with its evidence, and `stmt history ID` for its revisions. Use `stmt resolve --context JSON` for rules whose CEL conditions depend on the context. A statement with no conditionals matches every context, so `resolve` does not narrow those by subject.
2. **From a generated view.** A tool renders a document such as `CLAUDE.md` or `AGENTS.md` from the store's enabled heads, and renders it again whenever the store changes. A view puts each statement's id beside it, carries a banner naming its generator and the command that regenerates it, and has a check mode that fails when it no longer matches the store. Regenerate the view; never edit it by hand.

Hand-written documents such as skills, briefs and notes drift. When one needs a rule, it cites the rule's id instead of restating it; where it does restate a rule, the store's enabled head wins. To change a rule, revise the statement (`revise ID --if-revision N`, or `import` with `expected_revision`), then regenerate every view built from it. `convert-md` is the one-way path in: once prose is migrated, its Markdown is evidence, not a second source.

## Try it

Requires Node.js 24.12 or newer with built-in SQLite and ICU time-zone data. The tool vendors its CEL implementation and has no npm dependencies, so it runs offline from `bin/stmt`.

```sh
stmt contract
export STMT_DB="$PWD/rules.sqlite" STMT_DOMAIN=studio STMT_SCOPE=/
stmt init
pkg="$(dirname "$(command -v stmt)")/../tools/stmt"
stmt import --file "$pkg/examples/domain.json"
stmt scope-add --scope /repo
export STMT_SCOPE=/repo
stmt import --file "$pkg/examples/repository.json"
stmt resolve --context '{"branch":"main","reviewed":true}'
```

Here the repository's JSON instruction shadows the domain's Markdown default. The domain's review policy still applies.

<!-- readme-example: skip: the first gate exits 3 by design, and ack needs the action_id and token claim returns -->
```sh
stmt gate --json '{"id":"write-41","operation":"code.write","context":{"branch":"main","reviewed":false}}'
# Exit 3, decision BLOCK. The host stops this write.
stmt gate --json '{"id":"write-42","operation":"code.write","context":{"branch":"main","reviewed":true}}'
# After ALLOW and a successful external write:
stmt emit --json '{"id":"written-42","cause":"write-42","operation":"code.write","result":{"files":1}}'
stmt work written-42
stmt claim --json '{"event_id":"written-42","worker":"agent-1"}'
# Use action_id and token returned by claim.
stmt ack --json '{"action_id":"ACTION_ID","token":"LEASE_TOKEN","status":"succeeded","result":{"passed":17}}'
stmt events --json '{"pending_only":true,"limit":50}'
```

The first task is `code.check`. Its successful acknowledgment releases `report.publish`. The second worker receives the test result in `item.inputs["write.test"].result`. Run the included end-to-end example with `node "$pkg/examples/demo.mjs"`.

## Connect a host

Import the adapter from this checkout's `tools/stmt/src/adapter.js`.

```js
import {AgentHost} from '/path/to/super-tools/tools/stmt/src/adapter.js';

const host = new AgentHost({
  db: '/var/lib/my-agent/rules.sqlite',
  domain: 'studio',
  scope: '/repo',
  handlers: {
    'code.write': ({context, idempotency_key}) => editor.writeOnce(idempotency_key, context),
    'code.check': ({context, idempotency_key}) => ci.checkOnce(idempotency_key, context),
    'report.publish': ({inputs, idempotency_key}) =>
      reports.publishOnce(idempotency_key, inputs['write.test'].result)
  }
});
const context = {branch: 'main', reviewed: true};
const instructions = host.instructions(context);
if (!instructions.complete) throw new Error('Missing facts for policy resolution');
// Supply instructions.matched to the agent as authoritative scoped guidance.
const run = await host.perform({id: 'request-427', operation: 'code.write', context});
if (run.status === 'succeeded') {
  while (await host.runNext(run.after.event_id, 'agent-1')) { /* drain ready work */ }
}
```

The host must supply trusted facts such as review status, pin the boundary, and route each relevant tool through the gate. The model may supply ordinary task facts. Keep authority facts out of model-controlled inputs. `AgentHost` consumes policies and dispatches only explicitly registered handlers. Connect the store at session startup to replace Markdown discovery. References to local scripts or skill assets belong in evidence or in a registered handler.

A host can also implement the protocol in another language. Every command writes one UTF-8 JSON envelope to stdout. `stmt contract` returns the command catalog, input schemas, precedence and exit codes. To obtain complete live guidance, read `result.matched` and check `result.errors`. A gate permits the host operation only on `ALLOW`. A `BLOCK` or `INDETERMINATE` decision has `ok:true` because the decision itself was recorded.

| Exit | Meaning |
| --- | --- |
| 0 | Command succeeded |
| 1 | Storage or runtime error |
| 2 | Invalid input, CEL, scope syntax or graph |
| 3 | Gate returned BLOCK |
| 4 | Evaluation indeterminate or guidance incomplete |
| 5 | Revision, identity or lease conflict, or a busy database |
| 6 | Unavailable boundary/resource or disabled authoring |

## Boundaries and precedence

A database is bound to one domain on initialization. Every command supplies a domain, database and registered context path through flags or `STMT_DB`, `STMT_DOMAIN` and `STMT_SCOPE`. `scope-add` requires an existing parent. At `/repo/api` an agent inherits from `/` and `/repo` and can read its local records. Sibling and descendant records stay outside its view. Writing an existing statement requires its exact owner scope. Events, cursors, leases and results are local to the exact event scope.

A trusted launcher can pin those environment values. Flags may narrow a pinned scope to a registered descendant. `STMT_POLICY_MODE=consume` disables policy authoring while allowing decisions and work receipts. For mutually untrusted actors, expose the adapter from a separate OS identity that owns the file and controls which operations the caller may invoke. A process with unrestricted shell access to the SQLite file can write it directly. New database files use mode 0600 on POSIX, subject to the filesystem.

1. Select the latest enabled, unexpired revision of each visible statement. Expiry never resurrects an older revision.
2. Match the event kind, phase and operation. Evaluate CEL conditions against `ctx`, `event`, `domain` and `scope`. The engine supplies the latter three on delivery. All conditions must be true. An empty list matches. `resolve` also accepts hypothetical event facts for a read-only preview.
3. Any matching `BLOCK` vetoes a `BEFORE` event across priorities. With no veto, an unresolved CEL error returns `INDETERMINATE`. Either decision withholds all actions.
4. Plain guidance with the same `override_key` has one winner. Lower numeric priority wins, then the deeper scope, then ascending ID. `resolve` includes both the winner and the shadowed IDs. Other guidance accumulates. Operational rules cannot declare override keys.
5. Prerequisites determine action order. Among eligible actions, priority, scope depth and ID break ties. `event` returns matched, false, errored and dependency-suppressed rules with their revisions.

## Author and migrate

`create ID` and `revise ID --if-revision N` accept complete documents via `--json`, `--file PATH` or `--file -`. Statement text is 1–512 Unicode code points, with spaces counted. Supply a nonblank `statement`, `owner:{type,id}` and `category`. Optional fields include `priority` (0–4), `ttl_seconds`, `evidence`, Boolean CEL `conditionals`, `enabled`, `override_key`, `rule` and `requires`. Setting `enabled:false` appends a retired revision. TTL starts anew at each revision. `get` and `history` expose past or expired records for inspection.

The trigger operation and requested action are separate. This example runs a check after a write changed at least one file.

```json
{
  "statement": "Run the code checks after a write changes files.",
  "owner": {"type":"team","id":"platform"},
  "category": "quality",
  "conditionals": ["event.result.files > 0"],
  "rule": {
    "effect": "ACT",
    "trigger": {"kind":"EVENT","phase":"AFTER","operation":"code.write"},
    "action": {"operation":"code.check"}
  }
}
```

`requires` lists prerequisite statement IDs. Both endpoints must be ACT rules with identical triggers. The predecessor must be visible from the dependent's scope. `import` accepts forward references in one atomic batch and rejects cycles, missing prerequisites, and cross-boundary links. Editing a referenced trigger can require updating several records in the same batch. A false, expired or disabled prerequisite suppresses its dependents for that occurrence. Failed work cancels its descendants. Unrelated branches may finish.

To migrate prose, preview each source before import. `convert-md` splits paragraphs at Unicode boundaries and records the source file, line span and content digest as evidence. It creates plain instructions. An author can add explicit CEL, actions and chains to the preview.

<!-- readme-example: skip: needs an AGENTS.md in the working directory and a database the Try it example set up -->
```sh
stmt convert-md --markdown AGENTS.md --json '{"prefix":"repo.agents","owner":{"type":"team","id":"platform"},"category":"guidance"}' > preview.json
stmt import --file preview.json
stmt list --category guidance
```

Use the same flow for `SKILL.md` or `AGENT.md`. Identical reimports are idempotent. An edited record requires its current `expected_revision`. Review changed paragraph IDs and retire obsolete entries explicitly. `export` produces authoring documents owned by the selected scope. To back up revision history, events and leases together, use SQLite's backup facility. For a populated standalone v1/v2 database, back up the file and run `stmt init --adopt` at `/`. Adoption validates current heads and places legacy statements at the domain root. Oversized current v1 text must first be superseded with a compliant revision; older text remains readable.

## Events, schedules and recovery

Event identity is `(domain, scope, id)`. The same normalized request returns its original decision and pinned revisions, including after later policy changes. Reusing the ID for different facts or a different operation returns a conflict. Use a fresh ID for a new attempt. Optional `cause` links a same-scope event to an accepted parent and its root. Repeated phase/operation pairs on one causal path and paths deeper than 16 hops are rejected. An independent inbound `emit` is a trusted notification. For host-controlled operations, attach the successful gate as its cause.

`events` pages the local journal using a monotonic per-scope `cursor`. Pass it back as `after`. `pending_only:true` finds unfinished events after a restart. `claim` grants a time-limited lease, with a default of 60 seconds and a maximum of 3,600. A later worker can reclaim an expired lease. The `action_id` survives retries. Apply that key at the external side-effect boundary. `ack` accepts the matching live token and a JSON result. Retrying the same final acknowledgement is idempotent. The adapter reuses an existing AFTER result. If a process dies between an external side effect and its AFTER record, the handler must deduplicate the retry. Thrown handler errors leave the item leased for retry; use a failed acknowledgement for a permanent failure.

A host timer invokes `tick` with an explicit window `(from, until]` in UTC epoch seconds. Persist the last acknowledged upper bound or replay an overlapping window. The limit is 24 hours and 1,000 distinct slots per call. Use stable context when replaying a slot. The scheduler can run a one-off `AT`, an elapsed `EVERY` interval with an anchor, or a five-field cron in a named time zone. Cron supports numeric values, month/weekday names, lists, ascending ranges and positive steps. Restricted day-of-month and weekday fields are ORed. Missing wall-clock times are skipped, and repeated local minutes have separate UTC identities. Only an active revision can create new work; a due slot must fall within that revision's lifetime. No background daemon is installed.

## Standalone archive

`make stmt-package` from the repository root, or `npm run -s package` in `tools/stmt/`, writes `generated/stmt-package/stmt-X.Y.Z.tar.gz` and `generated/stmt-package/SHA256SUMS`. `X.Y.Z` is the `version` in `package.json`. The archive holds `bin/stmt`, the sources, SQL, vendored CEL runtime, examples and notices. It leaves out tests and build scripts. Only files git tracks go in, so the archive matches the commit. Entries are sorted, owned by 0:0 and dated at the last commit, or at `SOURCE_DATE_EPOCH` when set, so the same commit builds the same bytes. `--out DIR` writes elsewhere. `--check stmt-vX.Y.Z` refuses a tag that does not match the version.

To install, verify and extract the archive, then put its `bin` on the path:

<!-- readme-example: skip: requires a built archive -->
```sh
sha256sum --check SHA256SUMS
tar -xzf stmt-X.Y.Z.tar.gz
export PATH="$PWD/stmt-X.Y.Z/bin:$PATH"
stmt contract
```

Keep `bin` and `tools` together inside the extracted directory. The archive needs only Node 24.12 or newer. `stmt --help` prints the manpage from the launcher when the repository's `st-man` is absent.

## Verification

Run `npm test` in `tools/stmt/`, or `make test-node` from the repository root. Node measures all first-party runtime files under `src/`, including the executable and host adapter. The test command enforces a 91% floor independently for lines, branches and functions. SQL behavior is exercised through real on-disk SQLite databases. The vendored CEL implementation, examples and tests are outside the first-party coverage denominator.
